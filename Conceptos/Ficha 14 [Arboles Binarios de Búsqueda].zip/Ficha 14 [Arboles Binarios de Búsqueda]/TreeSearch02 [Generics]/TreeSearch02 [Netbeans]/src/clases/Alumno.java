package clases;

/**
 *  Representa un alumno para usarse en estructuras de datos gen�ricas.
 *  @author Ing. Valerio Frittelli.
 *  @version Septiembre de 2013.
 */
public class Alumno implements Comparable<Alumno>
{
   private int legajo;
   private String nombre;
   
   /**
    * Constructor por defecto.
    */
   public Alumno ()
   {
   }
   
   /**
    * Inicializa el legajo con el valor del parametro.
    */
   public Alumno(int leg)
   {
      legajo = leg;
      nombre = "";
   }
   
   /**
    * Inicializa todos los atributos.
    */
   public Alumno(int leg, String nom)
   {
      legajo = leg;
      nombre = nom;
   }
   
   /**
    * Acceso al Legajo.
    * @return valor del legajo.
    */
   public int getLegajo()
   {
      return legajo;
   }
   
   /**
    * Acceso al nombre.
    * @return valor del nombre.
    */
   public String getNombre()
   {
      return nombre;
   }
   
   /**
    * Modifica el legajo.
    * @param leg nuevo legajo.
    */
   public void setLegajo(int leg)
   {
      legajo = leg;
   }
   
   /**
    * Modifica el nombre.
    * @param nom nuevo nombre.
    */
   public void setNombre(String nom)
   {
      nombre = nom;
   }
   
   /**
    *  Redefinici�n de toString.
    *  @return el contenido del nodo en forma de String.
    */
   @Override
   public String toString()
   {
     return "\r\nLegajo: " + legajo + "\tNombre: " + nombre; 
   }
   
   /**
    * Redefine el metodo compareTo().
    */
   @Override
   public int compareTo(Alumno o)
   {
       return this.legajo - o.legajo;
   }
}
